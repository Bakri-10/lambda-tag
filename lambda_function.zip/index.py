import boto3
import os
import logging

# Initialize the logger
logging.basicConfig(filename='untagged_efs.log', level=logging.INFO,
                    format='%(asctime)s:%(levelname)s:%(message)s')

# Initialize the Boto3 client for Amazon EFS
efs_client = boto3.client('efs')

# Get a list of all EFS file systems
response = efs_client.describe_file_systems()

# Extract the file system information from the response
file_systems = response['FileSystems']

# Iterate through each file system
for file_system in file_systems:
    # Check if the file system has any tags
    if 'Tags' not in file_system:
        # If the file system doesn't have any tags, add a "Name" tag with value "Untagged EFS"
        efs_client.create_tags(
            FileSystemId=file_system['FileSystemId'],
            Tags=[{'Key': os.environ['KEY'], 'Value': os.environ['VALUE']}]
        )
        logging.info(f"Added tag to untagged EFS file system {file_system['FileSystemId']}")

