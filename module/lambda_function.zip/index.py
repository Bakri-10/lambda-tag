import boto3
import os
import logging

ec2 = boto3.client('ec2')
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    response = ec2.describe_instances()

    untagged_instance_ids = []
    for reservation in response['Reservations']:
        for instance in reservation['Instances']:
            if not instance.get('Tags'):
                untagged_instance_ids.append(instance['InstanceId'])
                ec2.create_tags(
                    Resources=[instance['InstanceId']],
                    Tags=[{'Key': os.environ['KEY'], 'Value': os.environ['VALUE']}]
                )
                logger.info(f"Tagged instance {instance['InstanceId']} with Key={os.environ['KEY']} and Value={os.environ['VALUE']}")

    logger.info(f"Tagged {len(untagged_instance_ids)} untagged instances with Key={os.environ['KEY']} and Value={os.environ['VALUE']}")

